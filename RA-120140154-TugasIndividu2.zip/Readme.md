Ryan Ernanda
120140154
PBO - RA

Program ini merupakan program sederhana yaitu text editor dengan metode prosedural. 
Jika pengguna ingin memulai programnya maka pengguna perlu menekan tombol Open atau langsung menulisnya di kolom teks disebelah kanan.
Adapun fitur yang tersedia di program ini yaitu Membuat file baru dengan menulisnya langsung, membuka file" teks yang ada dan menyimpan file dengan lokasi yang ditentukan oleh pengguna.

